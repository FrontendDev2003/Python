# Задание 8_2, вариант 16(1)
N = int(input("Введите количество строк: "))
M = int(input("Введите количество столбцов: "))

print(f"Введите матрицу {N}x{M} построчно (числа через пробел):")

B = []
for i in range(N):
    row = list(map(int, input().split()))
    if len(row) != M:
        print(f"Ошибка: в строке должно быть {M} чисел!")
        exit()
    B.append(row)

print("\nИсходная матрица:")
for row in B:
    print(row)

for i in range(N):
    min_idx = 0
    max_idx = 0
    
    for j in range(1, M):
        if B[i][j] < B[i][min_idx]:
            min_idx = j
        if B[i][j] > B[i][max_idx]:
            max_idx = j
    
    if min_idx != M - 1:
        B[i][min_idx], B[i][M - 1] = B[i][M - 1], B[i][min_idx]
        if max_idx == M - 1:
            max_idx = min_idx
    
    if max_idx != 0:
        B[i][max_idx], B[i][0] = B[i][0], B[i][max_idx]

print("\nПреобразованная матрица:")
for row in B:
    print(row)