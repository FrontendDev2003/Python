# Задание 8_1, вариант 16(1)
N = int(input("Введите размер матрицы N: "))

A = []
print(f"Введите матрицу {N}x{N} построчно (элементы через пробел):")
for i in range(N):
    row = list(map(float, input().split()))
    A.append(row)

sum_positive = 0
count_positive = 0

for i in range(N):
    for j in range(N):
        if j > i:
            if A[i][j] > 0:
                sum_positive += A[i][j]
                count_positive += 1

print(f"\nМатрица {N}x{N}:")
for row in A:
    print(' '.join(map(str, row)))

print(f"\nЧисло положительных элементов над главной диагональю: {count_positive}")
print(f"Сумма положительных элементов над главной диагональю: {sum_positive}")