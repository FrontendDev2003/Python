# Задание 5, вариант 16(1)

text = input("Введите текст: ")
words = text.lower().split()
count = 0
for word in words:
    if word and word[0] == 'е':
        count += 1

print("Количество слов на 'е':", count)