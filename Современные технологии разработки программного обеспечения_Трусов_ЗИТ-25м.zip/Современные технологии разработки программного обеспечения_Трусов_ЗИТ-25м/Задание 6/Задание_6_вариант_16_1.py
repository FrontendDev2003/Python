# Задание 6, вариант 16(1)
n = int(input("Введите количество элементов: "))
arr = []

for i in range(n):
    arr.append(int(input(f"Элемент {i}: ")))

max_element = arr[0]
for num in arr:
    if num > max_element:
        max_element = num

print(f"\nМаксимальный элемент: {max_element}")
print("Массив в обратном порядке:")
for i in range(n-1, -1, -1):
    print(arr[i], end=" ")