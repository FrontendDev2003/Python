# Задание 6, вариант 16(1)
numbers = list(map(float, input("Введите числа через пробел: ").split()))
if numbers:
    avg = sum(numbers) / len(numbers)
    numbers = [avg if x == 0 else x for x in numbers]
print("Результат:", numbers)