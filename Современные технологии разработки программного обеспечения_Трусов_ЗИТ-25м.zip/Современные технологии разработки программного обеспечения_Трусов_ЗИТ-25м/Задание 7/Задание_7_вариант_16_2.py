# Задание 7_2, вариант 16(1)
array1 = [1, 2, 3, 4, 5]
array2 = [6, 7, 8, 9, 10]
array3 = [11, 12, 13, 14, 15]

sum1 = sum(array1)
avg1 = sum1 / len(array1)
sum2 = sum(array2)
avg2 = sum2 / len(array2)
sum3 = sum(array3)
avg3 = sum3 / len(array3)

print("Array1:", "Sum =", sum1, "Average =", avg1)
print("Array2:", "Sum =", sum2, "Average =", avg2)
print("Array3:", "Sum =", sum3, "Average =", avg3)
