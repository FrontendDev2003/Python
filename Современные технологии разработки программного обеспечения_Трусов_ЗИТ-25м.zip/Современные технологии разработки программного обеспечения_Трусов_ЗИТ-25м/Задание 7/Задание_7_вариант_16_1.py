# Задание 7_1, вариант 16(1)
circle_area = lambda r: 3.14159 * r * r
rectangle_area = lambda a, b: a * b
triangle_area = lambda base, height: 0.5 * base * height
square_area = lambda side: side * side
trapezoid_area = lambda a, b, h: 0.5 * (a + b) * h

print("1 - Круг")
print("2 - Прямоугольник")
print("3 - Треугольник")
print("4 - Квадрат")
print("5 - Трапеция")

choice = input("Введите номер фигуры (1-5): ")

if choice == '1':
    r = float(input("Введите радиус круга: "))
    print(f"Площадь: {circle_area(r):.2f}")
elif choice == '2':
    a = float(input("Введите длину прямоугольника: "))
    b = float(input("Введите ширину прямоугольника: "))
    print(f"Площадь: {rectangle_area(a, b):.2f}")
elif choice == '3':
    base = float(input("Введите основание треугольника: "))
    height = float(input("Введите высоту треугольника: "))
    print(f"Площадь: {triangle_area(base, height):.2f}")
elif choice == '4':
    side = float(input("Введите сторону квадрата: "))
    print(f"Площадь: {square_area(side):.2f}")
elif choice == '5':
    a = float(input("Введите первое основание трапеции: "))
    b = float(input("Введите второе основание трапеции: "))
    h = float(input("Введите высоту трапеции: "))
    print(f"Площадь: {trapezoid_area(a, b, h):.2f}")
else:
    print("Неверный выбор")