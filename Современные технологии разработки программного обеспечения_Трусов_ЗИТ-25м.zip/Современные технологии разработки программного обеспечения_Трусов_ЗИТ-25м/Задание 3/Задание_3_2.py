num = int(input("Введите число для переменной num: "))
if num % 2 == 0:
    print(f"Число {num} - чётное")
else:
    print(f"Число {num} - нечётное")
